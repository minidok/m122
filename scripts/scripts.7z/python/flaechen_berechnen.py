#!/usr/local/bin/python3

import geometrie
flaeche = geometrie.flaeche_dreieck(3,5)
print(flaeche)