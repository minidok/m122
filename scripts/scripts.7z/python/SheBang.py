#!/usr/local/bin/python3

import math

def meineFunktion(x):
    return 2*x**2

if __name__ == "__main__":
    meineFunktion(5)