## Linux Kommandos

Untenstehend eine nicht abschliessende Auflistung von häufig verwendeten Kommandos für Linux, gruppiert nach Anwendungsfall

Die meisten Kommandos sind mit Optionen und Parametern aufrufbar. Optionen können auf weggelassen werden

command *[options]*  <parameter>

### Dateien und Verzeichnisse

| Kommando                 | Beschreibung                                                 |
| ------------------------ | ------------------------------------------------------------ |
| **cd** <folder>          | In Verzeichnis <folder> wechseln                             |
| **pwd**                  | Gibt aktuelles Verzeichnis aus                               |
| **ls**                   | Listet den Inhalt des aktuellen Verzeichnis auf              |
| **mkdir** <folder>       | Erstellt ein Verzeichnis mit dem Namen <folder>              |
| **rmdir** <folder>       | Löscht ein Verzeichnis <folder>                              |
| **cp** <source> <target> | Kopiert eine Datei von <source> nach <target>                |
| **mv** <source> <target> | Verschiebt eine Datei von <source> nach <target>             |
| **touch** <file>         | Erstellt eine leere Datei <file> oder aktualisiert den Veränderungszeitpunkt, wenn die Datei bereits existiert |
| **chmod** <flags> <file> | Ändert die Berechtigung auf der Datei <file> gemäss den Angaben <flags> |
| **chown** <user> <file>  | Ändert den Eigentümer <user> für eine Datei <file>           |
| **chgrp** <group> <file> | Ändert die Gruppe <group> für eine Datei <file>              |

### Verwendung von Dateinhalten

| Kommando          | Beschreibung                                                 |
| ----------------- | ------------------------------------------------------------ |
| **cat** <file>    | Zeigt den Inhalt der Datei <file> auf standard output        |
| **wc** <file>     | Zählt die Anzahl Wörter der Datei <file>                     |
| **file** <file>   | Gibt den vom OS erkannten Dateityp für die angegebene Datei <file> aus |
| **head** <file>   | Gibt die ersten 10 Zeilen für die Datei <file> aus           |
| **tail** <file>   | Gibt die letzten 10 Zeilen für die Datei <file> aus          |
| **less** <file>   | Scrollt durch den Inhalt der Datei <file>, (Anzeige mit q verlassen) |
| **sort** <file>   | Sortiert die Textzeilen einer Datei alphabetisch             |
| **cut** -d' ' -f1 | Unterteilt Ausgabe in Felder, mit Trennzeichen Leerzeichen und gibt das Feld1 aus |

### Verwaltung von Prozessen

| Kommando       | Beschreibung                                                 |
| -------------- | ------------------------------------------------------------ |
| **ps**         | Listet alle Prozesse im Terminal für den aktuellen Benutzer auf.<br />Jeder Prozess hat eine Id <PID> |
| **ps** ax      | Listet alle Prozesse für jeden Benutzer, die gerade ausgeführt werden |
| **ps** e       | Zeigt neben dem Prozess die entsprechende Umgebung an        |
| **kill** <PID> | Befehlt beendet einen Prozess, indem er das Signal SIGTERM an den Prozess <PID> sendet |
| **fg**         | Bringt einen gestoppten oder in den Hintergrund gebrachten Job wieder in den Vodergrund |
| **bg**         | Bringt einen gestoppten Job in den Hintergrund               |
| **jobs**       | Listet alle Jobs auf                                         |
| **top**        | Zeigt die Prozesse, welche im Moment die meiste CPU Zeit brauchen (Verlassen mit q) |



### Kommandos die Ausgaben machen

| Kommando          | Beschreibung                                                 |
| ----------------- | ------------------------------------------------------------ |
| **echo** <string> | Gibt Meldung <string> auf Standard output aus                |
| **date**          | Gibt das aktuelle Systemdatum aus                            |
| **who**           | Gibt eine Liste der eingeloggten Benutzer aus                |
| **man** <command> | Zeigt die Hilfe und Beschreibung zu einem Befehl aus (Anzeige mit q verlassen, Suche mit /) |
| **uptime**        | Zeigt, wie lange das System schon läuft                      |
| **free** -h       | Zeigt die Grösse des ungenutzen Speichers für das System     |
|                   |                                                              |

### Ausgaben von Kommandos steuern (streams)

| Steuerzeichen             | Beschreibung                                                 |
| ------------------------- | ------------------------------------------------------------ |
| command **>** file        | Standard output in Datei umleiten (überschreibt bestehende Datei <file>) |
| command **>>** file       | Standard Output in Datei umleiten, an bestehende Datei <file> anhängen |
| command 2> file           | Standard Error Anzeige umleiten in Datei <file><br /> Mit "dev/null" wird Ausgabe verhindert |
| command1 **\|** command 2 | Verbindet Ausgabe von Command1 mit Eingabe von Command2      |
|                           |                                                              |
|                           |                                                              |

